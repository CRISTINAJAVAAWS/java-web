console.log("Hola!");

document.getElementById('volverBtn').onclick=function(){
	window.history.back();
}